<template>
  <div>
    Home
  </div>
</template>

<script setup>
console.log('home')
</script>

<style scoped>

</style>