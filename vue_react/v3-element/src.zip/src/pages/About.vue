<template>
  <div>
    About
  </div>
</template>

<script setup>
console.log('about');
</script>

<style scoped>

</style>