<script setup>

</script>

<template>
  <div>
    <router-view />
  </div>
</template>

<style scoped>
</style>
